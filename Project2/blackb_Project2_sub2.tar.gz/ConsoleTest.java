import junit.framework.TestCase;

public class ConsoleTest extends TestCase {
  
  /** THIS CLASS WAS NOT UNIT TESTED
    * All methods simply call other methods in other classes and respond to the user's input.
    * Logic was kept to a minimum - that was primarly handled by other classes. */
  
  public void testConsole() {
  }
  
}
