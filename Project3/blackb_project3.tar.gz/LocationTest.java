import junit.framework.TestCase;

public class LocationTest extends TestCase {
  
  /**
   * Unit testing was not required for this class - all methods followed simple logic */
  public void testX() {
  }
  
}
